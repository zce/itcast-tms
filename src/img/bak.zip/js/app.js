(function(angular) {
  'use strict';

  angular
    .module('itcast-tms', [
      'ngAnimate',
      'ngRoute',
      'itcast-tms.directives.autoActive',
      'itcast-tms.directives.dialog',
      'itcast-tms.directives.resize',
      'itcast-tms.controllers.main',
      'itcast-tms.areas.dashboard',
      'itcast-tms.areas.starter'
    ])
    .config(['$routeProvider', function($routeProvider) {
      $routeProvider.otherwise({ redirectTo: '/home' })
    }]);

}(angular));
