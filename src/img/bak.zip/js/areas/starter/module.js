(function(angular) {
  'use strict';

  angular
    .module('itcast-tms.areas.starter', [])
    .config(['$routeProvider', function($routeProvider) {
      $routeProvider.when('/starter', {
        controller: 'StarterController',
        templateUrl: 'starter_tmpl'
      })
    }])
    .controller('StarterController', ['$scope', function($scope) {

    }]);

}(angular));
