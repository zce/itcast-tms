(function(angular) {
  'use strict';

  angular.module('itcast-tms.directives.resize', [])
    .directive('resize', ['$document', function($document) {
      return {
        link: function(scope, element, attributes, controller) {
          let beginX = 0,
            beginWidth = 0;
          const sidebar = element.parent();
          // console.log(sidebar.css('width'));
          const mousemove = (e) => {
            let change = e.clientX - beginX;
            let sidebarWidth = beginWidth + change;
            if (sidebarWidth < 120)
              sidebarWidth = 120;
            sidebar.css('width', sidebarWidth + 'px');
            // setTimeout(() => { $scope.$apply(); }, 0)
          };
          const mouseup = (e) => {
            $document.off('mousemove', mousemove);
            $document.off('mouseup', mouseup);
            sidebar.css('-webkit-transition', 'width 0.2s ease-in-out');
          };
          element.on('mousedown', (e) => {
            beginX = e.clientX;
            beginWidth = parseInt(sidebar.css('width'));
            // console.log(beginWidth);
            sidebar.css('-webkit-transition', 'none');
            $document.on('mousemove', mousemove);
            $document.on('mouseup', mouseup);
          });
        }
      };
    }]);;

}(angular));
